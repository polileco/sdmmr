NEXTORJP.SYS contains error messages in Japanese and English,
and so it's about 300 bytes larger than NEXTOR.SYS, which has only English messages.

If you want to use NEXTORJP.SYS, you need to rename it to NEXTOR.SYS
for the Nextor kernel to recognize it.
